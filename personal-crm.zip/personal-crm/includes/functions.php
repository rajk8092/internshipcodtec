<?php
/**
 * functions.php
 * -------------
 * Core reusable helper functions shared across the entire application:
 * session handling, CSRF protection, XSS-safe output, authentication guards,
 * flash messaging, and secure file uploads.
 */

// Start session with secure options (only once)
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,   // JS cannot access cookie -> mitigates XSS session theft
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';

// ---------------------------------------------------------------
// SESSION TIMEOUT (auto logout after 30 minutes of inactivity)
// ---------------------------------------------------------------
define('SESSION_TIMEOUT', 1800); // 30 minutes in seconds

function checkSessionTimeout(): void
{
    if (isset($_SESSION['user_id'])) {
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            session_unset();
            session_destroy();
            header('Location: login.php?timeout=1');
            exit;
        }
        $_SESSION['last_activity'] = time();
    }
}

// ---------------------------------------------------------------
// AUTH HELPERS
// ---------------------------------------------------------------

/** Redirects to login page if user is not authenticated. */
function requireLogin(): void
{
    checkSessionTimeout();
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

/** Returns true if a user is currently logged in. */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/** Returns the logged-in user's ID, or null. */
function currentUserId(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

/** Fetches the full current user row from the database. */
function currentUser(): ?array
{
    if (!isLoggedIn()) return null;
    static $cached = null;
    if ($cached !== null) return $cached;

    $stmt = getDB()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([currentUserId()]);
    $cached = $stmt->fetch() ?: null;
    return $cached;
}

// ---------------------------------------------------------------
// CSRF PROTECTION
// ---------------------------------------------------------------

/** Generates (or reuses) a CSRF token for the session. */
function generateCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Outputs a hidden input field containing the CSRF token. */
function csrfField(): string
{
    $token = generateCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
}

/** Validates a submitted CSRF token; kills the request if invalid. */
function verifyCsrfToken(): void
{
    $submitted = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $submitted)) {
        http_response_code(403);
        die('Invalid or expired form submission (CSRF check failed). Please go back and try again.');
    }
}

// ---------------------------------------------------------------
// OUTPUT / SANITIZATION HELPERS
// ---------------------------------------------------------------

/** Escapes a string for safe HTML output (XSS protection). */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Trims and strips tags from raw user input (for plain-text fields). */
function cleanInput(?string $value): string
{
    return trim(strip_tags($value ?? ''));
}

// ---------------------------------------------------------------
// FLASH MESSAGES (toast notifications after redirect)
// ---------------------------------------------------------------

/** Stores a one-time flash message. Type: success | danger | warning | info */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/** Retrieves and clears the flash message, or null if none. */
function getFlash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// ---------------------------------------------------------------
// FILE UPLOAD (secure)
// ---------------------------------------------------------------

/**
 * Handles a secure image upload.
 * Validates real MIME type, extension whitelist, and size, then moves
 * the file to $destDir with a randomly generated name to avoid collisions.
 *
 * @return array{ok:bool, filename?:string, error?:string}
 */
function handleImageUpload(array $file, string $destDir, int $maxBytes = 3145728): array
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'error' => 'no_file'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'upload_error'];
    }
    if ($file['size'] > $maxBytes) {
        return ['ok' => false, 'error' => 'File is too large. Maximum size is 3 MB.'];
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
    ];

    // Verify the REAL mime type (not just the extension) to prevent disguised uploads
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($allowed[$mime])) {
        return ['ok' => false, 'error' => 'Only JPG, PNG, GIF, or WEBP images are allowed.'];
    }

    if (!is_dir($destDir)) {
        mkdir($destDir, 0755, true);
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    $target = rtrim($destDir, '/') . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $target)) {
        return ['ok' => false, 'error' => 'Failed to save the uploaded file.'];
    }

    return ['ok' => true, 'filename' => $filename];
}

// ---------------------------------------------------------------
// MISC HELPERS
// ---------------------------------------------------------------

/** Redirects to a given local page and stops execution. */
function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

/** Returns Bootstrap badge color class for a task priority. */
function priorityBadgeClass(string $priority): string
{
    return match ($priority) {
        'High'   => 'bg-danger',
        'Medium' => 'bg-warning text-dark',
        'Low'    => 'bg-secondary',
        default  => 'bg-secondary',
    };
}

/** Returns Bootstrap badge color class for a task status. */
function statusBadgeClass(string $status): string
{
    return match ($status) {
        'Completed'   => 'bg-success',
        'In Progress' => 'bg-info text-dark',
        'Pending'     => 'bg-secondary',
        default       => 'bg-secondary',
    };
}

/** Formats a date for display (e.g. Jan 05, 2026). Returns "-" if null. */
function formatDate(?string $date): string
{
    if (empty($date)) return '-';
    $ts = strtotime($date);
    return $ts ? date('M d, Y', $ts) : '-';
}
