<?php
// includes/header.php
// Shared <head> + opening <body>. $pageTitle should be set before including this file.
$pageTitle = $pageTitle ?? 'Personal CRM';
$user = function_exists('currentUser') ? currentUser() : null;
$darkMode = $user['dark_mode'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="<?= $darkMode ? 'dark' : 'light' ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> | Personal CRM</title>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<!-- Custom App CSS -->
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="<?= $darkMode ? 'dark-mode' : '' ?>">

<?php
// Show any flash (toast) message stored in the session
$flash = getFlash();
?>
<?php if ($flash): ?>
<div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 1080">
  <div class="toast align-items-center text-white bg-<?= e($flash['type']) ?> border-0 show" role="alert" id="flashToast">
    <div class="d-flex">
      <div class="toast-body"><?= e($flash['message']) ?></div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" onclick="document.getElementById('flashToast').remove()"></button>
    </div>
  </div>
</div>
<?php endif; ?>
