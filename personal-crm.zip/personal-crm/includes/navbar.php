<?php
// includes/navbar.php
// Top navbar + left sidebar. Requires $user (current user array) and currently active page in $activePage.
$activePage = $activePage ?? '';
$u = $user ?? currentUser();

function navLink(string $page, string $active, string $icon, string $label): string
{
    $isActive = ($active === $page) ? 'active' : '';
    return '<a class="nav-link sidebar-link ' . $isActive . '" href="' . e($page) . '.php">
                <i class="fa-solid ' . e($icon) . ' me-2"></i>' . e($label) . '
            </a>';
}
?>
<nav class="navbar navbar-expand-lg app-navbar sticky-top px-3">
  <button class="btn btn-outline-secondary d-lg-none me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarOffcanvas">
    <i class="fa-solid fa-bars"></i>
  </button>
  <a class="navbar-brand fw-bold" href="dashboard.php"><i class="fa-solid fa-address-book me-2"></i>Personal CRM</a>

  <form class="d-none d-md-flex ms-auto me-3" action="search.php" method="get" role="search">
    <input class="form-control form-control-sm" type="search" name="q" placeholder="Search contacts..." value="<?= e($_GET['q'] ?? '') ?>">
  </form>

  <div class="dropdown ms-auto ms-md-0">
    <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
      <img src="<?= $u && $u['avatar'] ? 'uploads/avatars/' . e($u['avatar']) : 'assets/images/default-avatar.png' ?>"
           class="rounded-circle me-2" width="32" height="32" style="object-fit:cover" alt="avatar">
      <span class="d-none d-sm-inline text-body"><?= e($u['full_name'] ?? 'User') ?></span>
    </a>
    <ul class="dropdown-menu dropdown-menu-end">
      <li><a class="dropdown-item" href="profile.php"><i class="fa-solid fa-user me-2"></i>Profile</a></li>
      <li><a class="dropdown-item" href="settings.php"><i class="fa-solid fa-gear me-2"></i>Settings</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
    </ul>
  </div>
</nav>

<div class="app-body">
  <!-- Sidebar (desktop) -->
  <aside class="app-sidebar d-none d-lg-flex flex-column">
    <?= navLink('dashboard', $activePage, 'fa-gauge', 'Dashboard') ?>
    <?= navLink('contacts', $activePage, 'fa-address-book', 'Contacts') ?>
    <?= navLink('tasks', $activePage, 'fa-list-check', 'Tasks') ?>
    <?= navLink('notes', $activePage, 'fa-note-sticky', 'Notes') ?>
    <?= navLink('reminders', $activePage, 'fa-bell', 'Reminders') ?>
    <?= navLink('search', $activePage, 'fa-magnifying-glass', 'Search') ?>
    <hr class="text-secondary">
    <?= navLink('profile', $activePage, 'fa-user', 'Profile') ?>
    <?= navLink('settings', $activePage, 'fa-gear', 'Settings') ?>
    <a class="nav-link sidebar-link text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a>
  </aside>

  <!-- Sidebar (mobile offcanvas) -->
  <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarOffcanvas">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title"><i class="fa-solid fa-address-book me-2"></i>Personal CRM</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column">
      <?= navLink('dashboard', $activePage, 'fa-gauge', 'Dashboard') ?>
      <?= navLink('contacts', $activePage, 'fa-address-book', 'Contacts') ?>
      <?= navLink('tasks', $activePage, 'fa-list-check', 'Tasks') ?>
      <?= navLink('notes', $activePage, 'fa-note-sticky', 'Notes') ?>
      <?= navLink('reminders', $activePage, 'fa-bell', 'Reminders') ?>
      <?= navLink('search', $activePage, 'fa-magnifying-glass', 'Search') ?>
      <hr>
      <?= navLink('profile', $activePage, 'fa-user', 'Profile') ?>
      <?= navLink('settings', $activePage, 'fa-gear', 'Settings') ?>
      <a class="nav-link sidebar-link text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a>
    </div>
  </div>

  <main class="app-content flex-grow-1 p-3 p-md-4">
