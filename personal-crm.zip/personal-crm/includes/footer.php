  </main>
</div>
<footer class="app-footer text-center py-3 small text-muted">
  &copy; <?= date('Y') ?> Personal CRM. All rights reserved.
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom App JS -->
<script src="assets/js/script.js"></script>
</body>
</html>
