<?php
/**
 * view_contact.php
 * Displays full details of a single contact: profile, tags, related notes,
 * tasks, and reminders.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();
$contactId = (int) ($_GET['id'] ?? 0);

$stmt = $db->prepare('SELECT c.*, cat.name AS category_name, cat.color AS category_color
                       FROM contacts c LEFT JOIN categories cat ON c.category_id = cat.id
                       WHERE c.id = ? AND c.user_id = ?');
$stmt->execute([$contactId, $userId]);
$contact = $stmt->fetch();

if (!$contact) {
    setFlash('danger', 'Contact not found.');
    redirect('contacts.php');
}

// Tags
$tagStmt = $db->prepare('SELECT t.name FROM tags t JOIN contact_tags ct ON t.id = ct.tag_id WHERE ct.contact_id = ?');
$tagStmt->execute([$contactId]);
$tags = array_column($tagStmt->fetchAll(), 'name');

// Related notes
$notesStmt = $db->prepare('SELECT * FROM notes WHERE contact_id = ? ORDER BY created_at DESC');
$notesStmt->execute([$contactId]);
$notes = $notesStmt->fetchAll();

// Related tasks
$tasksStmt = $db->prepare('SELECT * FROM tasks WHERE contact_id = ? ORDER BY due_date ASC');
$tasksStmt->execute([$contactId]);
$tasks = $tasksStmt->fetchAll();

// Related reminders
$remindersStmt = $db->prepare('SELECT * FROM reminders WHERE contact_id = ? ORDER BY remind_date ASC');
$remindersStmt->execute([$contactId]);
$reminders = $remindersStmt->fetchAll();

$pageTitle = e($contact['full_name']);
$activePage = 'contacts';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
  <h3 class="fw-bold mb-0"><i class="fa-solid fa-user me-2"></i>Contact Details</h3>
  <div>
    <a href="edit_contact.php?id=<?= (int) $contact['id'] ?>" class="btn btn-primary"><i class="fa-solid fa-pen me-1"></i>Edit</a>
    <a href="contacts.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i>Back</a>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="card text-center">
      <div class="card-body">
        <img src="<?= $contact['photo'] ? 'uploads/contacts/' . e($contact['photo']) : 'assets/images/default-avatar.png' ?>" class="contact-avatar-lg mb-3" alt="">
        <h4 class="fw-bold mb-0"><?= e($contact['full_name']) ?></h4>
        <p class="text-muted mb-2"><?= e($contact['position'] ?: '') ?><?= $contact['position'] && $contact['company'] ? ' at ' : '' ?><?= e($contact['company'] ?: '') ?></p>
        <?php if ($contact['category_name']): ?>
          <span class="badge mb-3" style="background-color: <?= e($contact['category_color']) ?>"><?= e($contact['category_name']) ?></span>
        <?php endif; ?>
        <div class="d-flex justify-content-center gap-2 flex-wrap">
          <?php foreach ($tags as $tag): ?>
            <span class="tag-badge"><?= e($tag) ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card mb-4">
      <div class="card-header bg-white"><strong>Contact Information</strong></div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-6"><i class="fa-solid fa-envelope text-primary me-2"></i><?= $contact['email'] ? '<a href="mailto:' . e($contact['email']) . '">' . e($contact['email']) . '</a>' : '<span class="text-muted">No email</span>' ?></div>
          <div class="col-md-6"><i class="fa-solid fa-phone text-primary me-2"></i><?= e($contact['phone'] ?: 'No phone') ?></div>
          <div class="col-md-6"><i class="fa-brands fa-whatsapp text-success me-2"></i><?= e($contact['whatsapp'] ?: 'No WhatsApp') ?></div>
          <div class="col-md-6"><i class="fa-solid fa-globe text-primary me-2"></i><?= $contact['website'] ? '<a href="' . e($contact['website']) . '" target="_blank" rel="noopener">' . e($contact['website']) . '</a>' : '<span class="text-muted">No website</span>' ?></div>
          <div class="col-md-6"><i class="fa-solid fa-location-dot text-primary me-2"></i><?= e($contact['address'] ?: 'No address') ?></div>
          <div class="col-md-6"><i class="fa-solid fa-cake-candles text-primary me-2"></i><?= formatDate($contact['birthday']) ?></div>
        </div>
        <?php if ($contact['notes']): ?>
          <hr>
          <strong>Notes:</strong>
          <p class="mb-0 mt-1"><?= nl2br(e($contact['notes'])) ?></p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Related Tasks -->
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center bg-white">
        <strong><i class="fa-solid fa-list-check me-2"></i>Related Tasks</strong>
        <a href="tasks.php?contact_id=<?= (int) $contact['id'] ?>" class="small">Add Task</a>
      </div>
      <ul class="list-group list-group-flush">
        <?php if (empty($tasks)): ?><li class="list-group-item text-muted">No tasks linked to this contact.</li><?php endif; ?>
        <?php foreach ($tasks as $t): ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <span><?= e($t['title']) ?> <span class="small text-muted">(<?= formatDate($t['due_date']) ?>)</span></span>
            <span class="badge <?= statusBadgeClass($t['status']) ?>"><?= e($t['status']) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>

    <!-- Related Notes -->
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center bg-white">
        <strong><i class="fa-solid fa-note-sticky me-2"></i>Related Notes</strong>
        <a href="notes.php?contact_id=<?= (int) $contact['id'] ?>" class="small">Add Note</a>
      </div>
      <ul class="list-group list-group-flush">
        <?php if (empty($notes)): ?><li class="list-group-item text-muted">No notes linked to this contact.</li><?php endif; ?>
        <?php foreach ($notes as $n): ?>
          <li class="list-group-item">
            <div class="fw-semibold"><?= e($n['title']) ?></div>
            <div class="small text-muted"><?= formatDate($n['created_at']) ?></div>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
