<?php
/**
 * logout.php
 * Destroys the current session and clears the "remember me" token, both
 * client-side (cookie) and server-side (database).
 */
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    // Clear remember_token in DB so the cookie can no longer be used
    $db = getDB();
    $stmt = $db->prepare('UPDATE users SET remember_token = NULL WHERE id = ?');
    $stmt->execute([currentUserId()]);
}

// Expire the cookie
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/');
}

$_SESSION = [];
session_unset();
session_destroy();

redirect('login.php');
