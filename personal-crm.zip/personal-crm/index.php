<?php
/**
 * index.php
 * Entry point of the application. Redirects based on auth state.
 */
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect('dashboard.php');
} else {
    redirect('login.php');
}
