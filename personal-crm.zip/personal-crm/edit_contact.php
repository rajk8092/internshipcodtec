<?php
/**
 * edit_contact.php
 * Updates an existing contact's information, photo, category, and tags.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();
$contactId = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

// Fetch the contact & ensure it belongs to the current user
$stmt = $db->prepare('SELECT * FROM contacts WHERE id = ? AND user_id = ?');
$stmt->execute([$contactId, $userId]);
$contact = $stmt->fetch();

if (!$contact) {
    setFlash('danger', 'Contact not found.');
    redirect('contacts.php');
}

// Load existing tags as a comma separated string
$tagStmt = $db->prepare('SELECT t.name FROM tags t JOIN contact_tags ct ON t.id = ct.tag_id WHERE ct.contact_id = ?');
$tagStmt->execute([$contactId]);
$existingTags = implode(', ', array_column($tagStmt->fetchAll(), 'name'));

$errors = [];
$old = [
    'full_name' => $contact['full_name'], 'company' => $contact['company'], 'position' => $contact['position'],
    'email' => $contact['email'], 'phone' => $contact['phone'], 'whatsapp' => $contact['whatsapp'],
    'address' => $contact['address'], 'website' => $contact['website'], 'birthday' => $contact['birthday'],
    'category_id' => $contact['category_id'], 'tags' => $existingTags, 'notes' => $contact['notes'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();

    foreach (['full_name','company','position','email','phone','whatsapp','address','website','birthday','category_id','tags','notes'] as $key) {
        $old[$key] = cleanInput($_POST[$key] ?? '');
    }

    if ($old['full_name'] === '') {
        $errors[] = 'Full name is required.';
    }
    if ($old['email'] !== '' && !filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if ($old['birthday'] !== '' && !strtotime($old['birthday'])) {
        $errors[] = 'Please enter a valid birthday date.';
    }

    $photoFilename = $contact['photo'];
    if (!empty($_FILES['photo']['name'])) {
        $uploadResult = handleImageUpload($_FILES['photo'], __DIR__ . '/uploads/contacts');
        if (!$uploadResult['ok']) {
            $errors[] = 'Failed to upload the photo. Please use JPG, PNG, GIF, or WEBP under 3MB.';
        } else {
            // Remove old photo file to avoid orphaned uploads
            if ($contact['photo'] && file_exists(__DIR__ . '/uploads/contacts/' . $contact['photo'])) {
                unlink(__DIR__ . '/uploads/contacts/' . $contact['photo']);
            }
            $photoFilename = $uploadResult['filename'];
        }
    }

    if (empty($errors)) {
        $upd = $db->prepare('UPDATE contacts SET category_id=?, full_name=?, company=?, position=?, email=?, phone=?, whatsapp=?, address=?, website=?, birthday=?, photo=?, notes=? WHERE id=? AND user_id=?');
        $upd->execute([
            $old['category_id'] ?: null,
            $old['full_name'],
            $old['company'] ?: null,
            $old['position'] ?: null,
            $old['email'] ?: null,
            $old['phone'] ?: null,
            $old['whatsapp'] ?: null,
            $old['address'] ?: null,
            $old['website'] ?: null,
            $old['birthday'] ?: null,
            $photoFilename,
            $old['notes'] ?: null,
            $contactId,
            $userId,
        ]);

        // ---- Re-sync tags: clear existing links, then re-add ----
        $db->prepare('DELETE FROM contact_tags WHERE contact_id = ?')->execute([$contactId]);
        $tagNames = array_filter(array_map('trim', explode(',', $old['tags'])));
        foreach ($tagNames as $tagName) {
            $tagStmt = $db->prepare('SELECT id FROM tags WHERE user_id = ? AND name = ?');
            $tagStmt->execute([$userId, $tagName]);
            $tag = $tagStmt->fetch();
            if ($tag) {
                $tagId = $tag['id'];
            } else {
                $insTag = $db->prepare('INSERT INTO tags (user_id, name) VALUES (?, ?)');
                $insTag->execute([$userId, $tagName]);
                $tagId = (int) $db->lastInsertId();
            }
            $db->prepare('INSERT IGNORE INTO contact_tags (contact_id, tag_id) VALUES (?, ?)')->execute([$contactId, $tagId]);
        }

        setFlash('success', 'Contact updated successfully.');
        redirect('view_contact.php?id=' . $contactId);
    }
}

$catStmt = $db->prepare('SELECT * FROM categories WHERE user_id = ? ORDER BY name');
$catStmt->execute([$userId]);
$categories = $catStmt->fetchAll();

$pageTitle = 'Edit Contact';
$activePage = 'contacts';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<h3 class="fw-bold mb-4"><i class="fa-solid fa-user-pen me-2"></i>Edit Contact</h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST" action="edit_contact.php?id=<?= (int) $contactId ?>" enctype="multipart/form-data" novalidate>
      <?= csrfField() ?>
      <input type="hidden" name="id" value="<?= (int) $contactId ?>">
      <div class="row g-3">
        <div class="col-md-4 text-center">
          <img src="<?= $contact['photo'] ? 'uploads/contacts/' . e($contact['photo']) : 'assets/images/default-avatar.png' ?>" class="contact-avatar-lg mb-2" id="photoPreview" alt="">
          <input type="file" name="photo" accept="image/*" class="form-control form-control-sm" onchange="document.getElementById('photoPreview').src = window.URL.createObjectURL(this.files[0])">
        </div>
        <div class="col-md-8">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Full Name *</label>
              <input type="text" name="full_name" class="form-control" value="<?= e($old['full_name']) ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Category</label>
              <select name="category_id" class="form-select">
                <option value="">-- None --</option>
                <?php foreach ($categories as $cat): ?>
                  <option value="<?= (int) $cat['id'] ?>" <?= $old['category_id'] == $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Company</label>
              <input type="text" name="company" class="form-control" value="<?= e($old['company']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Position</label>
              <input type="text" name="position" class="form-control" value="<?= e($old['position']) ?>">
            </div>
          </div>
        </div>
      </div>

      <hr class="my-4">

      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= e($old['email']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= e($old['phone']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">WhatsApp</label>
          <input type="text" name="whatsapp" class="form-control" value="<?= e($old['whatsapp']) ?>">
        </div>
        <div class="col-md-8">
          <label class="form-label">Address</label>
          <input type="text" name="address" class="form-control" value="<?= e($old['address']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Website</label>
          <input type="url" name="website" class="form-control" placeholder="https://" value="<?= e($old['website']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Birthday</label>
          <input type="date" name="birthday" class="form-control" value="<?= e($old['birthday']) ?>">
        </div>
        <div class="col-md-8">
          <label class="form-label">Tags <span class="text-muted small">(comma separated)</span></label>
          <input type="text" name="tags" class="form-control" value="<?= e($old['tags']) ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Notes</label>
          <textarea name="notes" class="form-control" rows="4"><?= e($old['notes']) ?></textarea>
        </div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-check me-1"></i>Update Contact</button>
        <a href="view_contact.php?id=<?= (int) $contactId ?>" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
