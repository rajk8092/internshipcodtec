<?php
/**
 * login.php
 * Authenticates users against the database and manages "Remember Me" cookies.
 */
require_once __DIR__ . '/includes/functions.php';

// Auto-login via remember_token cookie (if present and valid)
if (!isLoggedIn() && !empty($_COOKIE['remember_token'])) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM users WHERE remember_token = ?');
    $stmt->execute([$_COOKIE['remember_token']]);
    $rememberedUser = $stmt->fetch();
    if ($rememberedUser) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $rememberedUser['id'];
        $_SESSION['last_activity'] = time();
    }
}

if (isLoggedIn()) {
    redirect('dashboard.php');
}

$errors = [];
$oldEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();

    $email = strtolower(cleanInput($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember_me']);
    $oldEmail = $email;

    if ($email === '' || $password === '') {
        $errors[] = 'Please enter both email and password.';
    } else {
        $db = getDB();
        $stmt = $db->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Prevent session fixation
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['last_activity'] = time();

            if ($remember) {
                $token = bin2hex(random_bytes(32));
                $upd = $db->prepare('UPDATE users SET remember_token = ? WHERE id = ?');
                $upd->execute([$token, $user['id']]);
                // Cookie valid for 30 days
                setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true);
            }

            redirect('dashboard.php');
        } else {
            $errors[] = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | Personal CRM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="auth-wrapper">
  <div class="card auth-card p-4">
    <div class="card-body">
      <div class="text-center mb-4">
        <i class="fa-solid fa-address-book fa-2x text-primary"></i>
        <h3 class="mt-2 fw-bold">Welcome Back</h3>
        <p class="text-muted">Login to your Personal CRM</p>
      </div>

      <?php if (isset($_GET['timeout'])): ?>
        <div class="alert alert-warning">Your session expired due to inactivity. Please log in again.</div>
      <?php endif; ?>
      <?php if (isset($_GET['reset'])): ?>
        <div class="alert alert-success">Your password has been reset. Please log in.</div>
      <?php endif; ?>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="login.php" novalidate>
        <?= csrfField() ?>
        <div class="mb-3">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-control" value="<?= e($oldEmail) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember_me" id="rememberMe">
            <label class="form-check-label" for="rememberMe">Remember Me</label>
          </div>
          <a href="forgot_password.php" class="small">Forgot Password?</a>
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
      </form>

      <p class="text-center mt-3 mb-0">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
