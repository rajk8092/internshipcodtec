<?php
/**
 * tasks.php
 * Full task management: create, edit, delete, and status updates.
 * Uses Bootstrap modal windows for add/edit forms (single-page CRUD).
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();
$errors = [];

// ---- Handle Create/Update/Delete actions (POST) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $title = cleanInput($_POST['title'] ?? '');
        $description = cleanInput($_POST['description'] ?? '');
        $dueDate = cleanInput($_POST['due_date'] ?? '');
        $priority = in_array($_POST['priority'] ?? '', ['Low','Medium','High']) ? $_POST['priority'] : 'Medium';
        $status = in_array($_POST['status'] ?? '', ['Pending','In Progress','Completed']) ? $_POST['status'] : 'Pending';
        $contactId = (int) ($_POST['contact_id'] ?? 0) ?: null;

        if ($title === '') {
            setFlash('danger', 'Task title is required.');
        } else {
            if ($action === 'create') {
                $stmt = $db->prepare('INSERT INTO tasks (user_id, contact_id, title, description, due_date, priority, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$userId, $contactId, $title, $description ?: null, $dueDate ?: null, $priority, $status]);
                setFlash('success', 'Task created successfully.');

                // Auto-create a due-date reminder
                if ($dueDate) {
                    $db->prepare("INSERT INTO reminders (user_id, contact_id, title, type, remind_date) VALUES (?, ?, ?, 'Due Date', ?)")
                       ->execute([$userId, $contactId, 'Task Due: ' . $title, $dueDate]);
                }
            } else {
                $taskId = (int) ($_POST['task_id'] ?? 0);
                $stmt = $db->prepare('UPDATE tasks SET contact_id=?, title=?, description=?, due_date=?, priority=?, status=? WHERE id=? AND user_id=?');
                $stmt->execute([$contactId, $title, $description ?: null, $dueDate ?: null, $priority, $status, $taskId, $userId]);
                setFlash('success', 'Task updated successfully.');
            }
        }
        redirect('tasks.php');
    }

    if ($action === 'delete') {
        $taskId = (int) ($_POST['task_id'] ?? 0);
        $db->prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?')->execute([$taskId, $userId]);
        setFlash('success', 'Task deleted.');
        redirect('tasks.php');
    }

    if ($action === 'toggle_complete') {
        $taskId = (int) ($_POST['task_id'] ?? 0);
        $newStatus = $_POST['new_status'] ?? 'Completed';
        $newStatus = in_array($newStatus, ['Pending','In Progress','Completed']) ? $newStatus : 'Completed';
        $db->prepare('UPDATE tasks SET status = ? WHERE id = ? AND user_id = ?')->execute([$newStatus, $taskId, $userId]);
        redirect('tasks.php');
    }
}

// ---- Filters ----
$statusFilter = in_array($_GET['status'] ?? '', ['Pending','In Progress','Completed']) ? $_GET['status'] : '';
$priorityFilter = in_array($_GET['priority'] ?? '', ['Low','Medium','High']) ? $_GET['priority'] : '';

$where = ['t.user_id = ?'];
$params = [$userId];
if ($statusFilter) { $where[] = 't.status = ?'; $params[] = $statusFilter; }
if ($priorityFilter) { $where[] = 't.priority = ?'; $params[] = $priorityFilter; }
$whereSql = implode(' AND ', $where);

$stmt = $db->prepare("SELECT t.*, c.full_name AS contact_name FROM tasks t LEFT JOIN contacts c ON t.contact_id = c.id WHERE $whereSql ORDER BY FIELD(t.status,'Pending','In Progress','Completed'), t.due_date ASC");
$stmt->execute($params);
$tasks = $stmt->fetchAll();

// Contacts for the "link to contact" dropdown
$contactsStmt = $db->prepare('SELECT id, full_name FROM contacts WHERE user_id = ? ORDER BY full_name');
$contactsStmt->execute([$userId]);
$allContacts = $contactsStmt->fetchAll();

$preselectedContact = (int) ($_GET['contact_id'] ?? 0);

$pageTitle = 'Tasks';
$activePage = 'tasks';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h3 class="fw-bold mb-0">Tasks</h3>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#taskModal" onclick="openCreateModal()">
    <i class="fa-solid fa-plus me-1"></i>Add Task
  </button>
</div>

<!-- Filters -->
<div class="card mb-4">
  <div class="card-body">
    <form method="GET" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small mb-1">Status</label>
        <select name="status" class="form-select">
          <option value="">All Statuses</option>
          <?php foreach (['Pending','In Progress','Completed'] as $s): ?>
            <option value="<?= $s ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= $s ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label small mb-1">Priority</label>
        <select name="priority" class="form-select">
          <option value="">All Priorities</option>
          <?php foreach (['Low','Medium','High'] as $p): ?>
            <option value="<?= $p ?>" <?= $priorityFilter === $p ? 'selected' : '' ?>><?= $p ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-grid">
        <button class="btn btn-outline-primary" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr><th>Title</th><th>Contact</th><th>Due Date</th><th>Priority</th><th>Status</th><th class="text-end">Actions</th></tr>
      </thead>
      <tbody>
        <?php if (empty($tasks)): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No tasks found.</td></tr>
        <?php endif; ?>
        <?php foreach ($tasks as $t): ?>
          <tr>
            <td>
              <span class="<?= $t['status'] === 'Completed' ? 'text-decoration-line-through text-muted' : '' ?>"><?= e($t['title']) ?></span>
            </td>
            <td><?= e($t['contact_name'] ?: '-') ?></td>
            <td><?= formatDate($t['due_date']) ?></td>
            <td><span class="badge <?= priorityBadgeClass($t['priority']) ?>"><?= e($t['priority']) ?></span></td>
            <td><span class="badge <?= statusBadgeClass($t['status']) ?>"><?= e($t['status']) ?></span></td>
            <td class="text-end">
              <?php if ($t['status'] !== 'Completed'): ?>
                <form method="POST" class="d-inline">
                  <?= csrfField() ?>
                  <input type="hidden" name="action" value="toggle_complete">
                  <input type="hidden" name="task_id" value="<?= (int) $t['id'] ?>">
                  <input type="hidden" name="new_status" value="Completed">
                  <button class="btn btn-sm btn-outline-success" title="Mark Complete"><i class="fa-solid fa-check"></i></button>
                </form>
              <?php endif; ?>
              <button class="btn btn-sm btn-outline-primary" title="Edit"
                onclick='openEditModal(<?= json_encode($t, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>
                <i class="fa-solid fa-pen"></i>
              </button>
              <form method="POST" class="d-inline js-confirm-delete" data-confirm-message="Delete this task?">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="task_id" value="<?= (int) $t['id'] ?>">
                <button class="btn btn-sm btn-outline-danger" title="Delete"><i class="fa-solid fa-trash"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Task Modal (Add/Edit) -->
<div class="modal fade" id="taskModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" id="taskForm">
        <?= csrfField() ?>
        <input type="hidden" name="action" id="formAction" value="create">
        <input type="hidden" name="task_id" id="taskId" value="">
        <div class="modal-header">
          <h5 class="modal-title" id="taskModalTitle">Add Task</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" id="taskTitle" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" id="taskDescription" class="form-control" rows="3"></textarea>
          </div>
          <div class="row g-2">
            <div class="col-md-6">
              <label class="form-label">Due Date</label>
              <input type="date" name="due_date" id="taskDueDate" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="form-label">Priority</label>
              <select name="priority" id="taskPriority" class="form-select">
                <option value="Low">Low</option>
                <option value="Medium" selected>Medium</option>
                <option value="High">High</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" id="taskStatus" class="form-select">
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Link to Contact</label>
              <select name="contact_id" id="taskContact" class="form-select">
                <option value="">-- None --</option>
                <?php foreach ($allContacts as $c): ?>
                  <option value="<?= (int) $c['id'] ?>" <?= $preselectedContact === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['full_name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Task</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openCreateModal() {
    document.getElementById('taskModalTitle').textContent = 'Add Task';
    document.getElementById('formAction').value = 'create';
    document.getElementById('taskForm').reset();
    document.getElementById('taskId').value = '';
    <?php if ($preselectedContact): ?>
    document.getElementById('taskContact').value = '<?= (int) $preselectedContact ?>';
    <?php endif; ?>
}
function openEditModal(task) {
    document.getElementById('taskModalTitle').textContent = 'Edit Task';
    document.getElementById('formAction').value = 'update';
    document.getElementById('taskId').value = task.id;
    document.getElementById('taskTitle').value = task.title;
    document.getElementById('taskDescription').value = task.description || '';
    document.getElementById('taskDueDate').value = task.due_date || '';
    document.getElementById('taskPriority').value = task.priority;
    document.getElementById('taskStatus').value = task.status;
    document.getElementById('taskContact').value = task.contact_id || '';
    new bootstrap.Modal(document.getElementById('taskModal')).show();
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
