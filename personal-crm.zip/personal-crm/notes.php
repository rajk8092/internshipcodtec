<?php
/**
 * notes.php
 * Rich text notes management (create, edit, delete). Rich formatting is
 * achieved via a lightweight contentEditable toolbar (bold/italic/underline/lists),
 * stored as sanitized HTML.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();

/**
 * Sanitize rich-text HTML: only allow a safe whitelist of formatting tags to
 * prevent stored XSS via the contentEditable editor.
 */
function sanitizeRichText(string $html): string
{
    $allowed = '<b><strong><i><em><u><ul><ol><li><br><p><div><span>';
    $clean = strip_tags($html, $allowed);
    // Strip any inline event handlers or javascript: URLs that may have been pasted in
    $clean = preg_replace('/on\w+="[^"]*"/i', '', $clean);
    $clean = preg_replace('/javascript:/i', '', $clean);
    return $clean;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $title = cleanInput($_POST['title'] ?? '');
        $content = sanitizeRichText($_POST['content'] ?? '');
        $contactId = (int) ($_POST['contact_id'] ?? 0) ?: null;

        if ($title === '' || trim(strip_tags($content)) === '') {
            setFlash('danger', 'Please provide both a title and content for the note.');
        } elseif ($action === 'create') {
            $stmt = $db->prepare('INSERT INTO notes (user_id, contact_id, title, content) VALUES (?, ?, ?, ?)');
            $stmt->execute([$userId, $contactId, $title, $content]);
            setFlash('success', 'Note added successfully.');
        } else {
            $noteId = (int) ($_POST['note_id'] ?? 0);
            $stmt = $db->prepare('UPDATE notes SET title=?, content=?, contact_id=? WHERE id=? AND user_id=?');
            $stmt->execute([$title, $content, $contactId, $noteId, $userId]);
            setFlash('success', 'Note updated successfully.');
        }
        redirect('notes.php');
    }

    if ($action === 'delete') {
        $noteId = (int) ($_POST['note_id'] ?? 0);
        $db->prepare('DELETE FROM notes WHERE id = ? AND user_id = ?')->execute([$noteId, $userId]);
        setFlash('success', 'Note deleted.');
        redirect('notes.php');
    }
}

$stmt = $db->prepare('SELECT n.*, c.full_name AS contact_name FROM notes n LEFT JOIN contacts c ON n.contact_id = c.id WHERE n.user_id = ? ORDER BY n.created_at DESC');
$stmt->execute([$userId]);
$notes = $stmt->fetchAll();

$contactsStmt = $db->prepare('SELECT id, full_name FROM contacts WHERE user_id = ? ORDER BY full_name');
$contactsStmt->execute([$userId]);
$allContacts = $contactsStmt->fetchAll();

$preselectedContact = (int) ($_GET['contact_id'] ?? 0);

$pageTitle = 'Notes';
$activePage = 'notes';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h3 class="fw-bold mb-0">Notes</h3>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#noteModal" onclick="openCreateNoteModal()">
    <i class="fa-solid fa-plus me-1"></i>Add Note
  </button>
</div>

<div class="row g-3">
  <?php if (empty($notes)): ?>
    <div class="col-12"><div class="card"><div class="card-body text-center text-muted py-5">No notes yet. Click "Add Note" to create your first one.</div></div></div>
  <?php endif; ?>
  <?php foreach ($notes as $n): ?>
    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-body">
          <h5 class="card-title"><?= e($n['title']) ?></h5>
          <?php if ($n['contact_name']): ?><div class="small text-muted mb-2"><i class="fa-solid fa-user me-1"></i><?= e($n['contact_name']) ?></div><?php endif; ?>
          <div class="note-content small" style="max-height: 120px; overflow: hidden;"><?= $n['content'] /* sanitized on save */ ?></div>
        </div>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
          <span class="small text-muted"><?= formatDate($n['created_at']) ?></span>
          <div>
            <button class="btn btn-sm btn-outline-primary" onclick='openEditNoteModal(<?= json_encode($n, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i class="fa-solid fa-pen"></i></button>
            <form method="POST" class="d-inline js-confirm-delete" data-confirm-message="Delete this note?">
              <?= csrfField() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="note_id" value="<?= (int) $n['id'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Note Modal -->
<div class="modal fade" id="noteModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" id="noteForm" onsubmit="document.getElementById('noteContentHidden').value = document.getElementById('noteEditor').innerHTML;">
        <?= csrfField() ?>
        <input type="hidden" name="action" id="noteFormAction" value="create">
        <input type="hidden" name="note_id" id="noteId" value="">
        <input type="hidden" name="content" id="noteContentHidden">
        <div class="modal-header">
          <h5 class="modal-title" id="noteModalTitle">Add Note</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" id="noteTitle" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Link to Contact</label>
            <select name="contact_id" id="noteContact" class="form-select">
              <option value="">-- None --</option>
              <?php foreach ($allContacts as $c): ?>
                <option value="<?= (int) $c['id'] ?>" <?= $preselectedContact === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['full_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-2">
            <label class="form-label">Content *</label>
            <!-- Simple rich-text toolbar -->
            <div class="btn-toolbar mb-1" role="toolbar">
              <div class="btn-group btn-group-sm me-1">
                <button type="button" class="btn btn-outline-secondary" onmousedown="event.preventDefault()" onclick="document.execCommand('bold')"><i class="fa-solid fa-bold"></i></button>
                <button type="button" class="btn btn-outline-secondary" onmousedown="event.preventDefault()" onclick="document.execCommand('italic')"><i class="fa-solid fa-italic"></i></button>
                <button type="button" class="btn btn-outline-secondary" onmousedown="event.preventDefault()" onclick="document.execCommand('underline')"><i class="fa-solid fa-underline"></i></button>
              </div>
              <div class="btn-group btn-group-sm">
                <button type="button" class="btn btn-outline-secondary" onmousedown="event.preventDefault()" onclick="document.execCommand('insertUnorderedList')"><i class="fa-solid fa-list-ul"></i></button>
                <button type="button" class="btn btn-outline-secondary" onmousedown="event.preventDefault()" onclick="document.execCommand('insertOrderedList')"><i class="fa-solid fa-list-ol"></i></button>
              </div>
            </div>
            <div id="noteEditor" class="form-control" contenteditable="true" style="min-height: 180px;"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Note</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openCreateNoteModal() {
    document.getElementById('noteModalTitle').textContent = 'Add Note';
    document.getElementById('noteFormAction').value = 'create';
    document.getElementById('noteId').value = '';
    document.getElementById('noteForm').reset();
    document.getElementById('noteEditor').innerHTML = '';
    <?php if ($preselectedContact): ?>
    document.getElementById('noteContact').value = '<?= (int) $preselectedContact ?>';
    <?php endif; ?>
}
function openEditNoteModal(note) {
    document.getElementById('noteModalTitle').textContent = 'Edit Note';
    document.getElementById('noteFormAction').value = 'update';
    document.getElementById('noteId').value = note.id;
    document.getElementById('noteTitle').value = note.title;
    document.getElementById('noteContact').value = note.contact_id || '';
    document.getElementById('noteEditor').innerHTML = note.content;
    new bootstrap.Modal(document.getElementById('noteModal')).show();
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
