<?php
/**
 * search.php
 * Global search across contacts (name, email, phone, company, notes) with
 * optional category, company, and tag filters.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();

$query      = cleanInput($_GET['q'] ?? '');
$categoryId = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$company    = cleanInput($_GET['company'] ?? '');
$tagId      = isset($_GET['tag']) ? (int) $_GET['tag'] : 0;

$results = [];

if ($query !== '' || $categoryId || $company !== '' || $tagId) {
    $where = ['c.user_id = ?'];
    $params = [$userId];
    $joins = 'LEFT JOIN categories cat ON c.category_id = cat.id';

    if ($query !== '') {
        $where[] = '(c.full_name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.company LIKE ? OR c.notes LIKE ?)';
        $like = "%$query%";
        array_push($params, $like, $like, $like, $like, $like);
    }
    if ($categoryId) {
        $where[] = 'c.category_id = ?';
        $params[] = $categoryId;
    }
    if ($company !== '') {
        $where[] = 'c.company LIKE ?';
        $params[] = "%$company%";
    }
    if ($tagId) {
        $joins .= ' JOIN contact_tags ct ON ct.contact_id = c.id AND ct.tag_id = ?';
        // The JOIN clause is rendered before the WHERE clause in the final SQL string,
        // so its placeholder must be the FIRST bound parameter, ahead of all WHERE params.
        array_unshift($params, $tagId);
    }

    $whereSql = implode(' AND ', $where);
    $sql = "SELECT DISTINCT c.*, cat.name AS category_name, cat.color AS category_color
            FROM contacts c $joins
            WHERE $whereSql
            ORDER BY c.full_name ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll();
}

$catStmt = $db->prepare('SELECT * FROM categories WHERE user_id = ? ORDER BY name');
$catStmt->execute([$userId]);
$categories = $catStmt->fetchAll();

$tagStmt = $db->prepare('SELECT * FROM tags WHERE user_id = ? ORDER BY name');
$tagStmt->execute([$userId]);
$allTags = $tagStmt->fetchAll();

$pageTitle = 'Search';
$activePage = 'search';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<h3 class="fw-bold mb-4"><i class="fa-solid fa-magnifying-glass me-2"></i>Global Search</h3>

<div class="card mb-4">
  <div class="card-body">
    <form method="GET" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small mb-1">Keyword</label>
        <input type="text" name="q" class="form-control" placeholder="Name, email, phone, company, notes..." value="<?= e($query) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label small mb-1">Category</label>
        <select name="category" class="form-select">
          <option value="0">All Categories</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= (int) $cat['id'] ?>" <?= $categoryId === (int) $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label small mb-1">Company</label>
        <input type="text" name="company" class="form-control" value="<?= e($company) ?>">
      </div>
      <div class="col-md-2">
        <label class="form-label small mb-1">Tag</label>
        <select name="tag" class="form-select">
          <option value="0">All Tags</option>
          <?php foreach ($allTags as $tag): ?>
            <option value="<?= (int) $tag['id'] ?>" <?= $tagId === (int) $tag['id'] ? 'selected' : '' ?>><?= e($tag['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-1 d-grid">
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-search"></i></button>
      </div>
    </form>
  </div>
</div>

<?php if ($query !== '' || $categoryId || $company !== '' || $tagId): ?>
  <p class="text-muted"><?= count($results) ?> result(s) found.</p>
  <div class="card">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr><th></th><th>Name</th><th>Company</th><th>Email</th><th>Phone</th><th>Category</th><th></th></tr>
        </thead>
        <tbody>
          <?php if (empty($results)): ?>
            <tr><td colspan="7" class="text-center text-muted py-4">No matching contacts found.</td></tr>
          <?php endif; ?>
          <?php foreach ($results as $c): ?>
            <tr>
              <td><img src="<?= $c['photo'] ? 'uploads/contacts/' . e($c['photo']) : 'assets/images/default-avatar.png' ?>" class="contact-avatar" alt=""></td>
              <td class="fw-semibold"><?= e($c['full_name']) ?></td>
              <td><?= e($c['company'] ?: '-') ?></td>
              <td><?= e($c['email'] ?: '-') ?></td>
              <td><?= e($c['phone'] ?: '-') ?></td>
              <td><?php if ($c['category_name']): ?><span class="badge" style="background-color: <?= e($c['category_color']) ?>"><?= e($c['category_name']) ?></span><?php else: ?>-<?php endif; ?></td>
              <td><a href="view_contact.php?id=<?= (int) $c['id'] ?>" class="btn btn-sm btn-outline-secondary">View</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php else: ?>
  <div class="text-center text-muted py-5"><i class="fa-solid fa-magnifying-glass fa-2x mb-3"></i><p>Enter a keyword or choose a filter above to search your contacts.</p></div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
