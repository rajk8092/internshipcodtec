<?php
/**
 * profile.php
 * Allows the user to update their profile info, upload an avatar, and
 * change their password (requires current password verification).
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $formType = $_POST['form_type'] ?? '';

    // ---- Update Profile Info ----
    if ($formType === 'update_profile') {
        $fullName = cleanInput($_POST['full_name'] ?? '');
        $phone = cleanInput($_POST['phone'] ?? '');
        $email = strtolower(cleanInput($_POST['email'] ?? ''));

        if ($fullName === '') {
            $errors[] = 'Full name is required.';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        } else {
            $check = $db->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
            $check->execute([$email, $userId]);
            if ($check->fetch()) {
                $errors[] = 'That email is already used by another account.';
            }
        }

        $avatarFilename = null;
        if (!empty($_FILES['avatar']['name'])) {
            $uploadResult = handleImageUpload($_FILES['avatar'], __DIR__ . '/uploads/avatars');
            if (!$uploadResult['ok']) {
                $errors[] = 'Failed to upload avatar. Use JPG, PNG, GIF, or WEBP under 3MB.';
            } else {
                $avatarFilename = $uploadResult['filename'];
            }
        }

        if (empty($errors)) {
            if ($avatarFilename) {
                $old = currentUser();
                if (!empty($old['avatar']) && file_exists(__DIR__ . '/uploads/avatars/' . $old['avatar'])) {
                    unlink(__DIR__ . '/uploads/avatars/' . $old['avatar']);
                }
                $stmt = $db->prepare('UPDATE users SET full_name=?, email=?, phone=?, avatar=? WHERE id=?');
                $stmt->execute([$fullName, $email, $phone ?: null, $avatarFilename, $userId]);
            } else {
                $stmt = $db->prepare('UPDATE users SET full_name=?, email=?, phone=? WHERE id=?');
                $stmt->execute([$fullName, $email, $phone ?: null, $userId]);
            }
            setFlash('success', 'Profile updated successfully.');
            redirect('profile.php');
        }
    }

    // ---- Change Password ----
    if ($formType === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        $hash = $stmt->fetch()['password'];

        if (!password_verify($current, $hash)) {
            $errors[] = 'Current password is incorrect.';
        }
        if (strlen($new) < 6) {
            $errors[] = 'New password must be at least 6 characters.';
        }
        if ($new !== $confirm) {
            $errors[] = 'New passwords do not match.';
        }

        if (empty($errors)) {
            $newHash = password_hash($new, PASSWORD_DEFAULT);
            $db->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([$newHash, $userId]);
            setFlash('success', 'Password changed successfully.');
            redirect('profile.php');
        }
    }
}

$user = currentUser();
$pageTitle = 'Profile';
$activePage = 'profile';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<h3 class="fw-bold mb-4"><i class="fa-solid fa-user me-2"></i>My Profile</h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white"><strong>Profile Information</strong></div>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <?= csrfField() ?>
          <input type="hidden" name="form_type" value="update_profile">
          <div class="text-center mb-3">
            <img src="<?= $user['avatar'] ? 'uploads/avatars/' . e($user['avatar']) : 'assets/images/default-avatar.png' ?>" class="contact-avatar-lg mb-2" id="avatarPreview" alt="">
            <input type="file" name="avatar" accept="image/*" class="form-control form-control-sm" onchange="document.getElementById('avatarPreview').src = window.URL.createObjectURL(this.files[0])">
          </div>
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="full_name" class="form-control" value="<?= e($user['full_name']) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" value="<?= e($user['email']) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= e($user['phone']) ?>">
          </div>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white"><strong>Change Password</strong></div>
      <div class="card-body">
        <form method="POST">
          <?= csrfField() ?>
          <input type="hidden" name="form_type" value="change_password">
          <div class="mb-3">
            <label class="form-label">Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">New Password</label>
            <input type="password" name="new_password" class="form-control" required minlength="6">
          </div>
          <div class="mb-3">
            <label class="form-label">Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control" required minlength="6">
          </div>
          <button type="submit" class="btn btn-danger">Change Password</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
