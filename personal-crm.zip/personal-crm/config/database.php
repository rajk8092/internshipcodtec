<?php
/**
 * Database Connection (PDO)
 * -------------------------
 * Provides a single PDO instance used across the whole application.
 * Uses prepared statements everywhere to prevent SQL Injection.
 */

// Database credentials - default XAMPP settings (root / no password)
define('DB_HOST', 'localhost');
define('DB_NAME', 'personal_crm');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

/**
 * getDB()
 * Returns a shared PDO connection instance (singleton pattern).
 */
function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Never leak raw DB errors to the browser in production.
            die('Database connection failed. Please make sure MySQL is running in XAMPP and the "personal_crm" database has been imported.');
        }
    }

    return $pdo;
}
