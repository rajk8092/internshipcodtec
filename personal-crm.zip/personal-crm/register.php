<?php
/**
 * register.php
 * Handles new user account creation.
 */
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect('dashboard.php');
}

$errors = [];
$old = ['full_name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();

    $fullName = cleanInput($_POST['full_name'] ?? '');
    $email    = strtolower(cleanInput($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    $old['full_name'] = $fullName;
    $old['email'] = $email;

    // ---- Validation ----
    if ($fullName === '' || strlen($fullName) < 2) {
        $errors[] = 'Please enter your full name.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        $db = getDB();

        // Check for duplicate email
        $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with this email already exists.';
        }
    }

    if (empty($errors)) {
        $db = getDB();
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $db->prepare('INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)');
        $stmt->execute([$fullName, $email, $hashed]);
        $newUserId = (int) $db->lastInsertId();

        // Seed default categories for the new user
        $defaultCategories = [
            ['Family', '#dc3545'],
            ['Friend', '#0d6efd'],
            ['Client', '#198754'],
            ['Colleague', '#fd7e14'],
        ];
        $catStmt = $db->prepare('INSERT INTO categories (user_id, name, color) VALUES (?, ?, ?)');
        foreach ($defaultCategories as $cat) {
            $catStmt->execute([$newUserId, $cat[0], $cat[1]]);
        }

        setFlash('success', 'Account created successfully! Please log in.');
        redirect('login.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | Personal CRM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="auth-wrapper">
  <div class="card auth-card p-4">
    <div class="card-body">
      <div class="text-center mb-4">
        <i class="fa-solid fa-address-book fa-2x text-primary"></i>
        <h3 class="mt-2 fw-bold">Create Account</h3>
        <p class="text-muted">Start managing your contacts today</p>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $err): ?>
              <li><?= e($err) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="register.php" novalidate>
        <?= csrfField() ?>
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control" value="<?= e($old['full_name']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-control" value="<?= e($old['email']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required minlength="6">
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm Password</label>
          <input type="password" name="confirm_password" class="form-control" required minlength="6">
        </div>
        <button type="submit" class="btn btn-primary w-100">Create Account</button>
      </form>

      <p class="text-center mt-3 mb-0">Already have an account? <a href="login.php">Login here</a></p>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
