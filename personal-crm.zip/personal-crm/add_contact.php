<?php
/**
 * add_contact.php
 * Creates a new contact, including profile picture upload and tag assignment.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();
$errors = [];

$old = [
    'full_name' => '', 'company' => '', 'position' => '', 'email' => '',
    'phone' => '', 'whatsapp' => '', 'address' => '', 'website' => '',
    'birthday' => '', 'category_id' => '', 'tags' => '', 'notes' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();

    foreach ($old as $key => $_) {
        $old[$key] = cleanInput($_POST[$key] ?? '');
    }

    if ($old['full_name'] === '') {
        $errors[] = 'Full name is required.';
    }
    if ($old['email'] !== '' && !filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if ($old['birthday'] !== '' && !strtotime($old['birthday'])) {
        $errors[] = 'Please enter a valid birthday date.';
    }

    // Handle photo upload (optional)
    $photoFilename = null;
    if (!empty($_FILES['photo']['name'])) {
        $uploadResult = handleImageUpload($_FILES['photo'], __DIR__ . '/uploads/contacts');
        if (!$uploadResult['ok']) {
            $errors[] = is_string($uploadResult['error']) && strlen($uploadResult['error']) > 20
                ? $uploadResult['error']
                : 'Failed to upload the photo. Please try a JPG, PNG, GIF, or WEBP file under 3MB.';
        } else {
            $photoFilename = $uploadResult['filename'];
        }
    }

    if (empty($errors)) {
        $stmt = $db->prepare('INSERT INTO contacts
            (user_id, category_id, full_name, company, position, email, phone, whatsapp, address, website, birthday, photo, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $userId,
            $old['category_id'] ?: null,
            $old['full_name'],
            $old['company'] ?: null,
            $old['position'] ?: null,
            $old['email'] ?: null,
            $old['phone'] ?: null,
            $old['whatsapp'] ?: null,
            $old['address'] ?: null,
            $old['website'] ?: null,
            $old['birthday'] ?: null,
            $photoFilename,
            $old['notes'] ?: null,
        ]);
        $contactId = (int) $db->lastInsertId();

        // ---- Handle tags (comma separated) ----
        $tagNames = array_filter(array_map('trim', explode(',', $old['tags'])));
        foreach ($tagNames as $tagName) {
            // Find or create the tag for this user
            $tagStmt = $db->prepare('SELECT id FROM tags WHERE user_id = ? AND name = ?');
            $tagStmt->execute([$userId, $tagName]);
            $tag = $tagStmt->fetch();
            if ($tag) {
                $tagId = $tag['id'];
            } else {
                $insTag = $db->prepare('INSERT INTO tags (user_id, name) VALUES (?, ?)');
                $insTag->execute([$userId, $tagName]);
                $tagId = (int) $db->lastInsertId();
            }
            $linkStmt = $db->prepare('INSERT IGNORE INTO contact_tags (contact_id, tag_id) VALUES (?, ?)');
            $linkStmt->execute([$contactId, $tagId]);
        }

        // Auto-create a birthday reminder if a birthday was provided
        if ($old['birthday']) {
            $remStmt = $db->prepare("INSERT INTO reminders (user_id, contact_id, title, type, remind_date) VALUES (?, ?, ?, 'Birthday', ?)");
            $remStmt->execute([$userId, $contactId, $old['full_name'] . "'s Birthday", $old['birthday']]);
        }

        setFlash('success', 'Contact added successfully.');
        redirect('view_contact.php?id=' . $contactId);
    }
}

$catStmt = $db->prepare('SELECT * FROM categories WHERE user_id = ? ORDER BY name');
$catStmt->execute([$userId]);
$categories = $catStmt->fetchAll();

$pageTitle = 'Add Contact';
$activePage = 'contacts';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<h3 class="fw-bold mb-4"><i class="fa-solid fa-user-plus me-2"></i>Add Contact</h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST" action="add_contact.php" enctype="multipart/form-data" novalidate>
      <?= csrfField() ?>
      <div class="row g-3">
        <div class="col-md-4 text-center">
          <img src="assets/images/default-avatar.png" class="contact-avatar-lg mb-2" id="photoPreview" alt="">
          <input type="file" name="photo" accept="image/*" class="form-control form-control-sm" onchange="document.getElementById('photoPreview').src = window.URL.createObjectURL(this.files[0])">
        </div>
        <div class="col-md-8">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Full Name *</label>
              <input type="text" name="full_name" class="form-control" value="<?= e($old['full_name']) ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Category</label>
              <select name="category_id" class="form-select">
                <option value="">-- None --</option>
                <?php foreach ($categories as $cat): ?>
                  <option value="<?= (int) $cat['id'] ?>" <?= $old['category_id'] == $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Company</label>
              <input type="text" name="company" class="form-control" value="<?= e($old['company']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Position</label>
              <input type="text" name="position" class="form-control" value="<?= e($old['position']) ?>">
            </div>
          </div>
        </div>
      </div>

      <hr class="my-4">

      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= e($old['email']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= e($old['phone']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">WhatsApp</label>
          <input type="text" name="whatsapp" class="form-control" value="<?= e($old['whatsapp']) ?>">
        </div>
        <div class="col-md-8">
          <label class="form-label">Address</label>
          <input type="text" name="address" class="form-control" value="<?= e($old['address']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Website</label>
          <input type="url" name="website" class="form-control" placeholder="https://" value="<?= e($old['website']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Birthday</label>
          <input type="date" name="birthday" class="form-control" value="<?= e($old['birthday']) ?>">
        </div>
        <div class="col-md-8">
          <label class="form-label">Tags <span class="text-muted small">(comma separated)</span></label>
          <input type="text" name="tags" class="form-control" placeholder="e.g. VIP, Investor, Gym Buddy" value="<?= e($old['tags']) ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Notes</label>
          <textarea name="notes" class="form-control" rows="4"><?= e($old['notes']) ?></textarea>
        </div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-check me-1"></i>Save Contact</button>
        <a href="contacts.php" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
