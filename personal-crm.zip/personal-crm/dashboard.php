<?php
/**
 * dashboard.php
 * Displays key statistics, recent contacts, upcoming tasks, birthdays, and reminders.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();

// ---- Statistics ----
$totalContacts = $db->prepare('SELECT COUNT(*) c FROM contacts WHERE user_id = ?');
$totalContacts->execute([$userId]);
$totalContacts = $totalContacts->fetch()['c'];

$totalTasksPending = $db->prepare("SELECT COUNT(*) c FROM tasks WHERE user_id = ? AND status != 'Completed'");
$totalTasksPending->execute([$userId]);
$totalTasksPending = $totalTasksPending->fetch()['c'];

$totalNotes = $db->prepare('SELECT COUNT(*) c FROM notes WHERE user_id = ?');
$totalNotes->execute([$userId]);
$totalNotes = $totalNotes->fetch()['c'];

$totalReminders = $db->prepare('SELECT COUNT(*) c FROM reminders WHERE user_id = ? AND is_done = 0');
$totalReminders->execute([$userId]);
$totalReminders = $totalReminders->fetch()['c'];

// ---- Recent Contacts (last 5 added) ----
$recentContacts = $db->prepare('SELECT * FROM contacts WHERE user_id = ? ORDER BY created_at DESC LIMIT 5');
$recentContacts->execute([$userId]);
$recentContacts = $recentContacts->fetchAll();

// ---- Upcoming Tasks (next 5, not completed, sorted by due date) ----
$upcomingTasks = $db->prepare("SELECT * FROM tasks WHERE user_id = ? AND status != 'Completed' AND due_date IS NOT NULL ORDER BY due_date ASC LIMIT 5");
$upcomingTasks->execute([$userId]);
$upcomingTasks = $upcomingTasks->fetchAll();

// ---- Upcoming Birthdays (next 30 days, based on month/day regardless of year) ----
$birthdaysStmt = $db->prepare("
    SELECT *,
        DATE_FORMAT(birthday, '%m-%d') AS bday_md,
        (DATEDIFF(
            DATE_ADD(birthday, INTERVAL (YEAR(CURDATE()) - YEAR(birthday) + IF(DATE_FORMAT(birthday,'%m-%d') < DATE_FORMAT(CURDATE(),'%m-%d'),1,0)) YEAR),
            CURDATE()
        )) AS days_until
    FROM contacts
    WHERE user_id = ? AND birthday IS NOT NULL
    HAVING days_until BETWEEN 0 AND 30
    ORDER BY days_until ASC
    LIMIT 5
");
$birthdaysStmt->execute([$userId]);
$upcomingBirthdays = $birthdaysStmt->fetchAll();

// ---- Reminder Summary (upcoming, not done) ----
$remindersStmt = $db->prepare("SELECT * FROM reminders WHERE user_id = ? AND is_done = 0 AND remind_date >= CURDATE() ORDER BY remind_date ASC LIMIT 5");
$remindersStmt->execute([$userId]);
$upcomingReminders = $remindersStmt->fetchAll();

$pageTitle = 'Dashboard';
$activePage = 'dashboard';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<h3 class="fw-bold mb-4">Welcome back, <?= e(explode(' ', $user['full_name'])[0]) ?> 👋</h3>

<!-- Statistics Cards -->
<div class="row g-3 mb-4">
  <div class="col-6 col-lg-3">
    <div class="card stat-card h-100">
      <div class="card-body d-flex align-items-center">
        <div class="stat-icon bg-primary me-3"><i class="fa-solid fa-address-book"></i></div>
        <div>
          <div class="text-muted small">Total Contacts</div>
          <div class="fs-4 fw-bold"><?= (int) $totalContacts ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card stat-card h-100">
      <div class="card-body d-flex align-items-center">
        <div class="stat-icon bg-warning me-3"><i class="fa-solid fa-list-check"></i></div>
        <div>
          <div class="text-muted small">Pending Tasks</div>
          <div class="fs-4 fw-bold"><?= (int) $totalTasksPending ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card stat-card h-100">
      <div class="card-body d-flex align-items-center">
        <div class="stat-icon bg-info me-3"><i class="fa-solid fa-note-sticky"></i></div>
        <div>
          <div class="text-muted small">Total Notes</div>
          <div class="fs-4 fw-bold"><?= (int) $totalNotes ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card stat-card h-100">
      <div class="card-body d-flex align-items-center">
        <div class="stat-icon bg-danger me-3"><i class="fa-solid fa-bell"></i></div>
        <div>
          <div class="text-muted small">Active Reminders</div>
          <div class="fs-4 fw-bold"><?= (int) $totalReminders ?></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- Recent Contacts -->
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header d-flex justify-content-between align-items-center bg-white">
        <strong><i class="fa-solid fa-address-book me-2 text-primary"></i>Recent Contacts</strong>
        <a href="contacts.php" class="small">View All</a>
      </div>
      <div class="list-group list-group-flush">
        <?php if (empty($recentContacts)): ?>
          <div class="list-group-item text-muted text-center py-4">No contacts yet. <a href="add_contact.php">Add your first contact</a>.</div>
        <?php endif; ?>
        <?php foreach ($recentContacts as $c): ?>
          <a href="view_contact.php?id=<?= (int) $c['id'] ?>" class="list-group-item list-group-item-action d-flex align-items-center">
            <img src="<?= $c['photo'] ? 'uploads/contacts/' . e($c['photo']) : 'assets/images/default-avatar.png' ?>" class="contact-avatar me-3" alt="">
            <div>
              <div class="fw-semibold"><?= e($c['full_name']) ?></div>
              <div class="small text-muted"><?= e($c['company'] ?: 'No company') ?></div>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Upcoming Tasks -->
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header d-flex justify-content-between align-items-center bg-white">
        <strong><i class="fa-solid fa-list-check me-2 text-warning"></i>Upcoming Tasks</strong>
        <a href="tasks.php" class="small">View All</a>
      </div>
      <div class="list-group list-group-flush">
        <?php if (empty($upcomingTasks)): ?>
          <div class="list-group-item text-muted text-center py-4">No upcoming tasks. <a href="tasks.php">Add a task</a>.</div>
        <?php endif; ?>
        <?php foreach ($upcomingTasks as $t): ?>
          <div class="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <div class="fw-semibold"><?= e($t['title']) ?></div>
              <div class="small text-muted"><i class="fa-regular fa-calendar me-1"></i><?= formatDate($t['due_date']) ?></div>
            </div>
            <span class="badge <?= priorityBadgeClass($t['priority']) ?>"><?= e($t['priority']) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Upcoming Birthdays -->
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header bg-white">
        <strong><i class="fa-solid fa-cake-candles me-2 text-danger"></i>Upcoming Birthdays (30 days)</strong>
      </div>
      <div class="list-group list-group-flush">
        <?php if (empty($upcomingBirthdays)): ?>
          <div class="list-group-item text-muted text-center py-4">No birthdays in the next 30 days.</div>
        <?php endif; ?>
        <?php foreach ($upcomingBirthdays as $b): ?>
          <a href="view_contact.php?id=<?= (int) $b['id'] ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
            <span><?= e($b['full_name']) ?></span>
            <span class="badge bg-danger-subtle text-danger"><?= (int) $b['days_until'] === 0 ? 'Today!' : (int) $b['days_until'] . ' days' ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Reminder Summary -->
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header d-flex justify-content-between align-items-center bg-white">
        <strong><i class="fa-solid fa-bell me-2 text-info"></i>Reminder Summary</strong>
        <a href="reminders.php" class="small">View All</a>
      </div>
      <div class="list-group list-group-flush">
        <?php if (empty($upcomingReminders)): ?>
          <div class="list-group-item text-muted text-center py-4">No upcoming reminders.</div>
        <?php endif; ?>
        <?php foreach ($upcomingReminders as $r): ?>
          <div class="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <div class="fw-semibold"><?= e($r['title']) ?></div>
              <div class="small text-muted"><?= e($r['type']) ?></div>
            </div>
            <span class="badge bg-secondary"><?= formatDate($r['remind_date']) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
