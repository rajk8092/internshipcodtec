# Personal CRM

A complete, production-quality Personal CRM web application built with **PHP 8, MySQL, Bootstrap 5, and vanilla JavaScript**, designed to run out-of-the-box on **XAMPP**.

## Features
- Authentication: Register, Login, Logout, Forgot/Reset Password, Remember Me, session timeout (30 min)
- Dashboard: stats cards, recent contacts, upcoming tasks, upcoming birthdays, reminder summary
- Contacts: full CRUD, profile picture upload, categories, tags, notes, birthday tracking
- Tasks: full CRUD via modals, priority, status, due dates, linked to contacts
- Notes: rich text (bold/italic/underline/lists) notes, linked to contacts
- Reminders: due-date & birthday reminders (auto-generated) + custom reminders
- Global Search: search + filter by category / company / tag
- Profile: update info, upload avatar, change password
- Settings: dark mode, notification toggle, account deletion

## Requirements
- XAMPP (PHP 8.0+, MySQL/MariaDB, Apache)

## Setup Instructions

1. **Copy the project folder** `personal-crm` into your XAMPP `htdocs` directory, e.g.:
   - Windows: `C:\xampp\htdocs\personal-crm`
   - macOS/Linux: `/Applications/XAMPP/htdocs/personal-crm` or `/opt/lampp/htdocs/personal-crm`

2. **Start Apache and MySQL** from the XAMPP Control Panel.

3. **Create the database**:
   - Open `http://localhost/phpmyadmin`
   - Click **Import**, choose the file `database/personal_crm.sql`, and click **Go**.
   - This creates the `personal_crm` database with all tables and foreign keys.
   - Alternatively, run from a terminal: `mysql -u root -p < database/personal_crm.sql`

4. **Check database credentials** in `config/database.php` (defaults match a stock XAMPP install: user `root`, empty password). Edit if your MySQL setup differs.

5. **Visit the app**: open `http://localhost/personal-crm/` in your browser.

6. **Register a new account** and log in — you're ready to go!

## Folder Structure
```
personal-crm/
├── assets/            CSS, JS, images
├── config/            database.php (PDO connection)
├── controllers/       reserved for future controller extraction
├── models/            reserved for future model extraction
├── views/             reserved for future view extraction
├── includes/          header.php, footer.php, navbar.php, functions.php (shared helpers)
├── uploads/           user-uploaded avatars & contact photos (protected via .htaccess)
├── database/          personal_crm.sql (schema)
└── *.php              one page-controller per feature (dashboard, contacts, tasks, etc.)
```

> **Architecture note:** each top-level `.php` page acts as a lightweight controller: it
> validates input, talks to the database via prepared statements, and renders its own view
> using the shared `includes/header.php`, `includes/navbar.php`, and `includes/footer.php`
> layout partials. Shared logic (auth guards, CSRF, sanitization, file uploads) lives in
> `includes/functions.php`, keeping the codebase DRY while remaining simple to deploy on
> shared/XAMPP-style hosting with no build step, router, or autoloader required.

## Security Features
- **SQL Injection**: 100% PDO prepared statements, no raw string concatenation of user input into SQL
- **XSS**: all dynamic output passed through `e()` (htmlspecialchars); rich-text notes pass through an HTML tag whitelist filter
- **CSRF**: every state-changing form includes a per-session CSRF token verified server-side
- **Secure file uploads**: uploaded images are validated by real MIME type (not extension), size-limited, renamed randomly, and stored in a directory where script execution is blocked via `.htaccess`
- **Password hashing**: `password_hash()` / `password_verify()` (bcrypt)
- **Session security**: HttpOnly cookies, session regeneration on login, 30-minute inactivity timeout

## Default Categories
When you register, four default contact categories are automatically created: **Family, Friend, Client, Colleague**. You can add more from the Add/Edit Contact forms (extend via the `categories` table).

## Notes on "Forgot Password"
Since a stock XAMPP install has no configured outgoing mail server, the "Forgot Password" flow generates a secure, time-limited reset link and displays it directly on screen (clearly labeled as a local/dev fallback) instead of silently failing. In a real deployment, swap the comment in `forgot_password.php` for a call to `mail()` or a library like PHPMailer/SMTP to actually email the link.
