<?php
/**
 * delete_contact.php
 * Deletes a contact owned by the current user. Related notes/tags/reminders
 * are removed automatically via ON DELETE CASCADE foreign keys.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('contacts.php');
}

verifyCsrfToken();

$db = getDB();
$userId = currentUserId();
$contactId = (int) ($_POST['id'] ?? 0);

// Confirm ownership before deleting anything
$stmt = $db->prepare('SELECT photo FROM contacts WHERE id = ? AND user_id = ?');
$stmt->execute([$contactId, $userId]);
$contact = $stmt->fetch();

if ($contact) {
    // Remove the uploaded photo file if one exists
    if ($contact['photo'] && file_exists(__DIR__ . '/uploads/contacts/' . $contact['photo'])) {
        unlink(__DIR__ . '/uploads/contacts/' . $contact['photo']);
    }

    $del = $db->prepare('DELETE FROM contacts WHERE id = ? AND user_id = ?');
    $del->execute([$contactId, $userId]);

    setFlash('success', 'Contact deleted successfully.');
} else {
    setFlash('danger', 'Contact not found or already deleted.');
}

redirect('contacts.php');
