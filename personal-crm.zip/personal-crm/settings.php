<?php
/**
 * settings.php
 * App preferences: dark mode, notification toggle, and account settings
 * (including permanent account deletion).
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $formType = $_POST['form_type'] ?? '';

    if ($formType === 'preferences') {
        $darkMode = isset($_POST['dark_mode']) ? 1 : 0;
        $notifications = isset($_POST['notifications_enabled']) ? 1 : 0;
        $db->prepare('UPDATE users SET dark_mode = ?, notifications_enabled = ? WHERE id = ?')
           ->execute([$darkMode, $notifications, $userId]);
        setFlash('success', 'Preferences updated successfully.');
        redirect('settings.php');
    }

    if ($formType === 'delete_account') {
        $password = $_POST['confirm_password'] ?? '';
        $stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        $hash = $stmt->fetch()['password'];

        if (!password_verify($password, $hash)) {
            $errors[] = 'Password is incorrect. Account was not deleted.';
        } else {
            // Cascading foreign keys will clean up contacts, tasks, notes, reminders, tags, categories
            $db->prepare('DELETE FROM users WHERE id = ?')->execute([$userId]);
            session_unset();
            session_destroy();
            redirect('register.php');
        }
    }
}

$user = currentUser();
$pageTitle = 'Settings';
$activePage = 'settings';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<h3 class="fw-bold mb-4"><i class="fa-solid fa-gear me-2"></i>Settings</h3>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white"><strong>App Preferences</strong></div>
      <div class="card-body">
        <form method="POST">
          <?= csrfField() ?>
          <input type="hidden" name="form_type" value="preferences">
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" name="dark_mode" id="darkModeSwitch" <?= $user['dark_mode'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="darkModeSwitch">Dark Mode</label>
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" name="notifications_enabled" id="notificationsSwitch" <?= $user['notifications_enabled'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="notificationsSwitch">Enable Notification Reminders</label>
          </div>
          <button type="submit" class="btn btn-primary">Save Preferences</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card border-danger">
      <div class="card-header bg-danger text-white"><strong><i class="fa-solid fa-triangle-exclamation me-2"></i>Danger Zone</strong></div>
      <div class="card-body">
        <p class="text-muted">Deleting your account is permanent and will remove all your contacts, tasks, notes, and reminders. This cannot be undone.</p>
        <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
          <i class="fa-solid fa-trash me-1"></i>Delete My Account
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Delete Account Modal -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="form_type" value="delete_account">
        <div class="modal-header">
          <h5 class="modal-title text-danger">Confirm Account Deletion</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p>This action is <strong>permanent</strong>. Please enter your password to confirm.</p>
          <input type="password" name="confirm_password" class="form-control" placeholder="Your password" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger">Permanently Delete Account</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
