<?php
/**
 * forgot_password.php
 * Generates a password reset token/link for a given account email.
 * NOTE: XAMPP does not have an SMTP server configured by default, so instead of
 * silently failing, the reset link is displayed directly on screen (clearly
 * labeled as a local/dev fallback) as well as prepared for real email sending.
 */
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect('dashboard.php');
}

$errors = [];
$resetLink = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $email = strtolower(cleanInput($_POST['email'] ?? ''));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    } else {
        $db = getDB();
        $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // Always show a generic success message (do not reveal if the email exists)
        if ($user) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600); // 1 hour validity

            $upd = $db->prepare('UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?');
            $upd->execute([$token, $expires, $user['id']]);

            $scheme = (!empty($_SERVER['HTTPS']) ? 'https' : 'http');
            $resetLink = $scheme . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/reset_password.php?token=' . $token;

            // In a live server, this is where mail() or an SMTP library (e.g. PHPMailer) would send $resetLink to $email.
        }

        setFlash('info', 'If that email exists in our system, a password reset link has been generated.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password | Personal CRM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="auth-wrapper">
  <div class="card auth-card p-4">
    <div class="card-body">
      <div class="text-center mb-4">
        <i class="fa-solid fa-key fa-2x text-primary"></i>
        <h3 class="mt-2 fw-bold">Forgot Password</h3>
        <p class="text-muted">Enter your email to receive a reset link</p>
      </div>

      <?php $flash = getFlash(); if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
      <?php endif; ?>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <?php if ($resetLink): ?>
        <div class="alert alert-warning">
          <strong>Local Dev Mode:</strong> No SMTP server is configured in XAMPP by default, so here is your reset link:<br>
          <a href="<?= e($resetLink) ?>" class="text-break"><?= e($resetLink) ?></a>
        </div>
      <?php endif; ?>

      <form method="POST" action="forgot_password.php" novalidate>
        <?= csrfField() ?>
        <div class="mb-3">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Send Reset Link</button>
      </form>

      <p class="text-center mt-3 mb-0"><a href="login.php"><i class="fa-solid fa-arrow-left me-1"></i>Back to Login</a></p>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
