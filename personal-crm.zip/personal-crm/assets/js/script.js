/**
 * Personal CRM - Custom JS
 * Handles: toast auto-dismiss, delete confirmations, client-side table filter.
 */

document.addEventListener('DOMContentLoaded', function () {

    // Auto-dismiss the flash toast after 4 seconds
    const flashToast = document.getElementById('flashToast');
    if (flashToast) {
        setTimeout(() => {
            flashToast.classList.remove('show');
            flashToast.remove();
        }, 4000);
    }

    // Confirm before any destructive delete action
    document.querySelectorAll('.js-confirm-delete').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            const msg = form.getAttribute('data-confirm-message') || 'Are you sure you want to delete this item? This action cannot be undone.';
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });
    });

    // Live client-side filter for simple tables (data-filter-input -> data-filter-table)
    document.querySelectorAll('[data-filter-input]').forEach(function (input) {
        input.addEventListener('keyup', function () {
            const tableId = input.getAttribute('data-filter-input');
            const table = document.getElementById(tableId);
            if (!table) return;
            const filter = input.value.toLowerCase();
            table.querySelectorAll('tbody tr').forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    });

    // Enable all Bootstrap tooltips if present
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
        new bootstrap.Tooltip(el);
    });
});
