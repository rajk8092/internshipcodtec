<?php
/**
 * contacts.php
 * Lists all contacts belonging to the current user with search, filtering,
 * sorting, and pagination.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();

// ---- Filters ----
$search     = cleanInput($_GET['q'] ?? '');
$categoryId = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$company    = cleanInput($_GET['company'] ?? '');
$sort       = in_array($_GET['sort'] ?? '', ['full_name', 'company', 'created_at']) ? $_GET['sort'] : 'full_name';
$dir        = ($_GET['dir'] ?? 'asc') === 'desc' ? 'DESC' : 'ASC';

// ---- Pagination ----
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// ---- Build WHERE clause dynamically & safely (bound params) ----
$where = ['c.user_id = ?'];
$params = [$userId];

if ($search !== '') {
    $where[] = '(c.full_name LIKE ? OR c.email LIKE ? OR c.phone LIKE ?)';
    $like = "%$search%";
    array_push($params, $like, $like, $like);
}
if ($categoryId > 0) {
    $where[] = 'c.category_id = ?';
    $params[] = $categoryId;
}
if ($company !== '') {
    $where[] = 'c.company LIKE ?';
    $params[] = "%$company%";
}
$whereSql = implode(' AND ', $where);

// Total count for pagination
$countStmt = $db->prepare("SELECT COUNT(*) c FROM contacts c WHERE $whereSql");
$countStmt->execute($params);
$totalRows = $countStmt->fetch()['c'];
$totalPages = max(1, (int) ceil($totalRows / $perPage));

// Fetch contacts with category name
$sql = "SELECT c.*, cat.name AS category_name, cat.color AS category_color
        FROM contacts c
        LEFT JOIN categories cat ON c.category_id = cat.id
        WHERE $whereSql
        ORDER BY c.$sort $dir
        LIMIT $perPage OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$contacts = $stmt->fetchAll();

// Categories for filter dropdown
$catStmt = $db->prepare('SELECT * FROM categories WHERE user_id = ? ORDER BY name');
$catStmt->execute([$userId]);
$categories = $catStmt->fetchAll();

$pageTitle = 'Contacts';
$activePage = 'contacts';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

// Helper to preserve current query string when changing sort/page
function qs(array $override): string
{
    $params = array_merge($_GET, $override);
    return '?' . http_build_query($params);
}
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h3 class="fw-bold mb-0">Contacts <span class="text-muted fs-6">(<?= (int) $totalRows ?>)</span></h3>
  <a href="add_contact.php" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i>Add Contact</a>
</div>

<!-- Filters -->
<div class="card mb-4">
  <div class="card-body">
    <form method="GET" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label small mb-1">Search</label>
        <input type="text" name="q" class="form-control" placeholder="Name, email, or phone" value="<?= e($search) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label small mb-1">Category</label>
        <select name="category" class="form-select">
          <option value="0">All Categories</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= (int) $cat['id'] ?>" <?= $categoryId === (int) $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label small mb-1">Company</label>
        <input type="text" name="company" class="form-control" placeholder="Filter by company" value="<?= e($company) ?>">
      </div>
      <div class="col-md-2 d-grid">
        <button class="btn btn-outline-primary" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0" id="contactsTable">
      <thead class="table-light">
        <tr>
          <th></th>
          <th><a class="text-decoration-none text-dark" href="<?= qs(['sort' => 'full_name', 'dir' => $dir === 'ASC' ? 'desc' : 'asc']) ?>">Name <i class="fa-solid fa-sort"></i></a></th>
          <th><a class="text-decoration-none text-dark" href="<?= qs(['sort' => 'company', 'dir' => $dir === 'ASC' ? 'desc' : 'asc']) ?>">Company <i class="fa-solid fa-sort"></i></a></th>
          <th>Email</th>
          <th>Phone</th>
          <th>Category</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($contacts)): ?>
          <tr><td colspan="7" class="text-center text-muted py-4">No contacts found.</td></tr>
        <?php endif; ?>
        <?php foreach ($contacts as $c): ?>
          <tr>
            <td><img src="<?= $c['photo'] ? 'uploads/contacts/' . e($c['photo']) : 'assets/images/default-avatar.png' ?>" class="contact-avatar" alt=""></td>
            <td><a href="view_contact.php?id=<?= (int) $c['id'] ?>" class="fw-semibold text-decoration-none"><?= e($c['full_name']) ?></a></td>
            <td><?= e($c['company'] ?: '-') ?></td>
            <td><?= e($c['email'] ?: '-') ?></td>
            <td><?= e($c['phone'] ?: '-') ?></td>
            <td>
              <?php if ($c['category_name']): ?>
                <span class="badge" style="background-color: <?= e($c['category_color']) ?>"><?= e($c['category_name']) ?></span>
              <?php else: ?>-<?php endif; ?>
            </td>
            <td class="text-end">
              <a href="view_contact.php?id=<?= (int) $c['id'] ?>" class="btn btn-sm btn-outline-secondary" title="View"><i class="fa-solid fa-eye"></i></a>
              <a href="edit_contact.php?id=<?= (int) $c['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="fa-solid fa-pen"></i></a>
              <form action="delete_contact.php" method="POST" class="d-inline js-confirm-delete" data-confirm-message="Delete this contact permanently?">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fa-solid fa-trash"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<nav class="mt-3">
  <ul class="pagination justify-content-center">
    <?php for ($p = 1; $p <= $totalPages; $p++): ?>
      <li class="page-item <?= $p === $page ? 'active' : '' ?>">
        <a class="page-link" href="<?= qs(['page' => $p]) ?>"><?= $p ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
