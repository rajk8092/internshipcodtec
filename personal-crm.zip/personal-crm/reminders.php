<?php
/**
 * reminders.php
 * Manages due-date reminders, birthday reminders, and custom reminders.
 */
require_once __DIR__ . '/includes/functions.php';
requireLogin();

$db = getDB();
$userId = currentUserId();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $title = cleanInput($_POST['title'] ?? '');
        $remindDate = cleanInput($_POST['remind_date'] ?? '');
        $contactId = (int) ($_POST['contact_id'] ?? 0) ?: null;

        if ($title === '' || !strtotime($remindDate)) {
            setFlash('danger', 'Please provide a valid title and reminder date.');
        } else {
            $db->prepare("INSERT INTO reminders (user_id, contact_id, title, type, remind_date) VALUES (?, ?, ?, 'Custom', ?)")
               ->execute([$userId, $contactId, $title, $remindDate]);
            setFlash('success', 'Reminder added.');
        }
        redirect('reminders.php');
    }

    if ($action === 'toggle_done') {
        $id = (int) ($_POST['reminder_id'] ?? 0);
        $isDone = (int) ($_POST['is_done'] ?? 0);
        $db->prepare('UPDATE reminders SET is_done = ? WHERE id = ? AND user_id = ?')->execute([$isDone, $id, $userId]);
        redirect('reminders.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['reminder_id'] ?? 0);
        $db->prepare('DELETE FROM reminders WHERE id = ? AND user_id = ?')->execute([$id, $userId]);
        setFlash('success', 'Reminder deleted.');
        redirect('reminders.php');
    }
}

$stmt = $db->prepare('SELECT r.*, c.full_name AS contact_name FROM reminders r LEFT JOIN contacts c ON r.contact_id = c.id WHERE r.user_id = ? ORDER BY r.is_done ASC, r.remind_date ASC');
$stmt->execute([$userId]);
$reminders = $stmt->fetchAll();

$contactsStmt = $db->prepare('SELECT id, full_name FROM contacts WHERE user_id = ? ORDER BY full_name');
$contactsStmt->execute([$userId]);
$allContacts = $contactsStmt->fetchAll();

$pageTitle = 'Reminders';
$activePage = 'reminders';
$user = currentUser();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h3 class="fw-bold mb-0">Reminders</h3>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#reminderModal">
    <i class="fa-solid fa-plus me-1"></i>Add Reminder
  </button>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr><th></th><th>Title</th><th>Type</th><th>Contact</th><th>Date</th><th class="text-end">Actions</th></tr>
      </thead>
      <tbody>
        <?php if (empty($reminders)): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No reminders yet.</td></tr>
        <?php endif; ?>
        <?php foreach ($reminders as $r):
          $isPast = strtotime($r['remind_date']) < strtotime(date('Y-m-d'));
        ?>
          <tr class="<?= $r['is_done'] ? 'table-secondary' : '' ?>">
            <td>
              <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="toggle_done">
                <input type="hidden" name="reminder_id" value="<?= (int) $r['id'] ?>">
                <input type="hidden" name="is_done" value="<?= $r['is_done'] ? 0 : 1 ?>">
                <button class="btn btn-sm <?= $r['is_done'] ? 'btn-success' : 'btn-outline-secondary' ?>" title="Toggle Done">
                  <i class="fa-solid fa-check"></i>
                </button>
              </form>
            </td>
            <td class="<?= $r['is_done'] ? 'text-decoration-line-through text-muted' : '' ?>"><?= e($r['title']) ?></td>
            <td>
              <?php
                $typeIcon = $r['type'] === 'Birthday' ? 'fa-cake-candles text-danger' : ($r['type'] === 'Due Date' ? 'fa-list-check text-warning' : 'fa-bell text-info');
              ?>
              <i class="fa-solid <?= $typeIcon ?> me-1"></i><?= e($r['type']) ?>
            </td>
            <td><?= e($r['contact_name'] ?: '-') ?></td>
            <td class="<?= (!$r['is_done'] && $isPast) ? 'text-danger fw-semibold' : '' ?>"><?= formatDate($r['remind_date']) ?></td>
            <td class="text-end">
              <form method="POST" class="d-inline js-confirm-delete" data-confirm-message="Delete this reminder?">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="reminder_id" value="<?= (int) $r['id'] ?>">
                <button class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Reminder Modal -->
<div class="modal fade" id="reminderModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="create">
        <div class="modal-header">
          <h5 class="modal-title">Add Reminder</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Reminder Date *</label>
            <input type="date" name="remind_date" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Link to Contact</label>
            <select name="contact_id" class="form-select">
              <option value="">-- None --</option>
              <?php foreach ($allContacts as $c): ?>
                <option value="<?= (int) $c['id'] ?>"><?= e($c['full_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Reminder</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
